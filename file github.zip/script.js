/* =========================================================
   Generator Perangkat Pembelajaran Akuntansi
   Bagian utama:
   1. Two-way data binding (form -> kertas preview)
   2. localStorage (simpan & muat draft)
   3. Konversi PDF (html2pdf.js)
   ========================================================= */
(() => {
  'use strict';

  const STORAGE_KEY = 'gpa-akuntansi-draft-v1';

  const form      = document.getElementById('formRpp');
  const fields    = form.querySelectorAll('[data-bind]');
  const paper     = document.getElementById('paper');
  const pane      = document.getElementById('panePreview');
  const btnSimpan = document.getElementById('btnSimpan');
  const btnPdf    = document.getElementById('btnPdf');
  const statusEl  = document.getElementById('status');

  let dirty = false; // true jika ada perubahan yang belum disimpan

  /* ---------------------------------------------------------
     1. TWO-WAY DATA BINDING
     Setiap field punya data-bind="kunci"; elemen di kertas
     punya data-preview="kunci". Saat input berubah, teks pada
     elemen yang cocok langsung diganti.
     --------------------------------------------------------- */
  function renderField(el) {
    const key = el.dataset.bind;
    let text = el.value;

    // Untuk dropdown, tampilkan teks pilihan, bukan value-nya
    if (el.tagName === 'SELECT') {
      text = el.value ? el.options[el.selectedIndex].text : '';
    }
    text = text.trim();

    document.querySelectorAll(`[data-preview="${key}"]`).forEach((node) => {
      if (text) {
        node.textContent = text; // textContent mencegah injeksi HTML
        node.classList.remove('is-placeholder');
      } else {
        node.textContent = node.dataset.placeholder || '';
        node.classList.add('is-placeholder');
      }
    });
  }

  function renderAll() {
    fields.forEach(renderField);
  }

  // 'input' menangkap ketikan pada teks, textarea, dan perubahan dropdown
  form.addEventListener('input', (e) => {
    if (!e.target.matches('[data-bind]')) return;
    renderField(e.target);
    dirty = true;
    setStatus('Ada perubahan yang belum disimpan', 'dirty');
  });

  /* ---------------------------------------------------------
     2. LOCAL STORAGE
     --------------------------------------------------------- */
  function collectData() {
    const data = {};
    fields.forEach((el) => { data[el.dataset.bind] = el.value; });
    return data;
  }

  // Dipanggil saat tombol "Simpan Draft" diklik
  function saveDraft() {
    try {
      const payload = { savedAt: new Date().toISOString(), data: collectData() };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
      dirty = false;
      setStatus(`Draft tersimpan pukul ${formatTime(new Date(payload.savedAt))}`, 'saved');
    } catch (err) {
      console.error(err);
      setStatus('Draft gagal disimpan. Periksa pengaturan penyimpanan browser.', 'error');
    }
  }

  // Dipanggil otomatis saat halaman dibuka/di-refresh
  function loadDraft() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const payload = JSON.parse(raw);
      fields.forEach((el) => {
        const saved = payload.data && payload.data[el.dataset.bind];
        if (typeof saved === 'string') el.value = saved;
      });
      const when = new Date(payload.savedAt);
      setStatus(`Draft dimuat (disimpan ${formatDateTime(when)})`, 'saved');
    } catch (err) {
      console.error(err);
      setStatus('Draft lama tidak dapat dibaca', 'error');
    }
  }

  btnSimpan.addEventListener('click', saveDraft);

  // Peringatan jika halaman ditutup/di-refresh padahal ada perubahan yang belum disimpan
  window.addEventListener('beforeunload', (e) => {
    if (!dirty) return;
    e.preventDefault();
    e.returnValue = '';
  });

  /* ---------------------------------------------------------
     3. EKSPOR PDF (html2pdf.js)
     Kertas preview digandakan (clone), dipasang di luar layar
     dengan lebar 165 mm, lalu diubah menjadi PDF A4. Margin
     halaman diatur oleh html2pdf, sehingga halaman kedua dan
     seterusnya tetap punya margin yang rapi.
     --------------------------------------------------------- */
  function downloadPdf() {
    if (typeof html2pdf === 'undefined') {
      alert('Library html2pdf.js gagal dimuat. Periksa koneksi internet lalu muat ulang halaman.');
      return;
    }

    const clone = paper.cloneNode(true);
    clone.removeAttribute('id');
    clone.style.zoom = '';                 // buang skala layar kecil
    clone.classList.add('paper--export');
    // Kolom yang kosong dicetak sebagai tanda strip, bukan teks petunjuk
    clone.querySelectorAll('.is-placeholder').forEach((n) => { n.textContent = '–'; });

    const holder = document.createElement('div');
    holder.className = 'export-holder';
    holder.appendChild(clone);
    document.body.appendChild(holder);

    const materi = document.getElementById('materiPokok').value || 'Akuntansi';
    const options = {
      margin: [20, 25, 20, 20],            // [atas, kiri, bawah, kanan] dalam mm
      filename: `Modul-Ajar-${slugify(materi)}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true, scrollY: 0 },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
      pagebreak: { mode: ['css', 'legacy'], avoid: ['.keep-together', 'h3', 'h4', 'tr'] }
    };

    btnPdf.disabled = true;
    btnPdf.textContent = 'Membuat PDF…';

    html2pdf()
      .set(options)
      .from(clone)
      .save()                              // otomatis mengunduh file ke komputer
      .catch((err) => {
        console.error(err);
        alert('PDF gagal dibuat. Silakan coba lagi.');
      })
      .finally(() => {
        holder.remove();
        btnPdf.disabled = false;
        btnPdf.textContent = 'Download PDF';
      });
  }

  btnPdf.addEventListener('click', downloadPdf);

  /* ---------------------------------------------------------
     Pendukung
     --------------------------------------------------------- */
  function setStatus(message, state) {
    statusEl.textContent = message;
    statusEl.dataset.state = state;
  }

  function formatTime(d) {
    return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }).replace(':', '.');
  }

  function formatDateTime(d) {
    const date = d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
    return `${date}, ${formatTime(d)}`;
  }

  function slugify(text) {
    return text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'dokumen';
  }

  // Pada layar sempit, kecilkan kertas agar muat tanpa scroll samping
  function fitPaper() {
    paper.style.zoom = '';
    const available = pane.clientWidth - parseFloat(getComputedStyle(pane).paddingLeft) * 2;
    const scale = Math.min(1, available / paper.offsetWidth);
    if (scale < 1) paper.style.zoom = scale;
  }

  /* ---------------------------------------------------------
     Inisialisasi
     --------------------------------------------------------- */
  loadDraft();   // muat draft dari localStorage (jika ada)
  renderAll();   // tampilkan isi form (atau placeholder) di kertas
  fitPaper();
  new ResizeObserver(fitPaper).observe(pane);
})();
